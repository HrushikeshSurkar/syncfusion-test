// src/app/shared/advanced-search/models/filter-option.model.ts
export interface FilterOption {
  label: string;
  value: string;
}
